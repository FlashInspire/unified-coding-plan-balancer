var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0rfwta0._.js")
R.c("server/chunks/[root-of-the-server]__0t0fzw2._.js")
R.m(82553)
module.exports=R.m(82553).exports
