module.exports=[6268,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_preferences_route_actions_0f~ulh1.js.map