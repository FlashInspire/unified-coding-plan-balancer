module.exports=[31275,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_aggregate-reports_route_actions_00zpaa6.js.map