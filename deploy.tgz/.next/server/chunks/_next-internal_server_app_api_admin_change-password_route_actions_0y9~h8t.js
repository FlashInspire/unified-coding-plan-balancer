module.exports=[53631,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_change-password_route_actions_0y9~h8t.js.map