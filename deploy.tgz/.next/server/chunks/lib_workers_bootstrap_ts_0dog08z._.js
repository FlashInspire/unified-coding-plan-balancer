module.exports=[46276,o=>{"use strict";let t=globalThis;o.s(["startWorkers",0,function(){t.__ucpb_workers_started||(t.__ucpb_workers_started=!0,console.log("[ucpb] Boot-time initialization done (periodic tasks via /api/cron)."))}])}];

//# sourceMappingURL=lib_workers_bootstrap_ts_0dog08z._.js.map