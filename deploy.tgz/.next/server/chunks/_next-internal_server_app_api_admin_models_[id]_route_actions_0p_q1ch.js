module.exports=[22147,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_models_%5Bid%5D_route_actions_0p_q1ch.js.map