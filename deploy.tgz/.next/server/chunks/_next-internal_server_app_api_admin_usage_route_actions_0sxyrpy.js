module.exports=[33787,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_usage_route_actions_0sxyrpy.js.map