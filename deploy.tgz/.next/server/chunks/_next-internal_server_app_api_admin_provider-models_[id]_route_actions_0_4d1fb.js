module.exports=[89737,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_provider-models_%5Bid%5D_route_actions_0_4d1fb.js.map