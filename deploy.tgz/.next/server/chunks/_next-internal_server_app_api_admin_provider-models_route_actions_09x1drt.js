module.exports=[26375,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_provider-models_route_actions_09x1drt.js.map