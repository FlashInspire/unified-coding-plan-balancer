module.exports=[18659,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_providers_%5Bid%5D_route_actions_05.za8w.js.map