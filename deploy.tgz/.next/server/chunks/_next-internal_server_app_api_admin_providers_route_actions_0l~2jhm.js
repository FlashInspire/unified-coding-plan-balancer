module.exports=[59621,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_providers_route_actions_0l~2jhm.js.map