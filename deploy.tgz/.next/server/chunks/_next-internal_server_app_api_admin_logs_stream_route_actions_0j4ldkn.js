module.exports=[64932,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_logs_stream_route_actions_0j4ldkn.js.map