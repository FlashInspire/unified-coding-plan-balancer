module.exports=[97150,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_report_page_actions_0fa_cqp.js.map