module.exports=[31163,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_change-password_page_actions_0ffui9c.js.map