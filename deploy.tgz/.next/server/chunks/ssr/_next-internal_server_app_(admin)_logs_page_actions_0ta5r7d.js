module.exports=[61652,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_logs_page_actions_0ta5r7d.js.map