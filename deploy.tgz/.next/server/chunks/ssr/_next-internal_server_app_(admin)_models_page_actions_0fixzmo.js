module.exports=[42039,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_models_page_actions_0fixzmo.js.map