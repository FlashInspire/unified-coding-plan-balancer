module.exports=[13145,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_page_actions_03m_-5y.js.map