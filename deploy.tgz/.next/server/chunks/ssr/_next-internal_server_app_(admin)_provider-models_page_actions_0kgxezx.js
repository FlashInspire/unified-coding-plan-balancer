module.exports=[68663,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_provider-models_page_actions_0kgxezx.js.map