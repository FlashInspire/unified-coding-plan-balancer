module.exports=[27657,a=>{"use strict";let b=(0,a.i(9707).default)("power",[["path",{d:"M12 2v10",key:"mnfbl"}],["path",{d:"M18.4 6.6a9 9 0 1 1-12.77.04",key:"obofu9"}]]);a.s(["Power",0,b],27657)}];

//# sourceMappingURL=0p91_lucide-react_dist_esm_icons_power_mjs_0_q859o._.js.map