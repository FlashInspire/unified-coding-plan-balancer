var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/_0_aps_n._.js")
R.m(69449)
module.exports=R.m(69449).exports
