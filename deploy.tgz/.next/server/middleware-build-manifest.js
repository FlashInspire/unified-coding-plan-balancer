globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/0Y25MXeoCl2Fh5dql40Mx/_buildManifest.js",
    "static/0Y25MXeoCl2Fh5dql40Mx/_ssgManifest.js",
    "static/0Y25MXeoCl2Fh5dql40Mx/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/13tm8h8cve7w~.js",
    "static/chunks/0sldlycjryb-0.js",
    "static/chunks/0~zic_~jx0jl0.js",
    "static/chunks/0vn8x3pmotln2.js",
    "static/chunks/0i849itgt0bfo.js",
    "static/chunks/turbopack-0so~h.ehr-ru..js"
  ]
};
