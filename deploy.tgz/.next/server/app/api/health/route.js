var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__0g7vert._.js")
R.c("server/chunks/[root-of-the-server]__0bju8yw._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_0-jjhgq.js")
R.m(72922)
module.exports=R.m(72922).exports
