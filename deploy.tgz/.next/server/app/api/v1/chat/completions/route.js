var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/chat/completions/route.js")
R.c("server/chunks/_11xv.6c._.js")
R.c("server/chunks/[root-of-the-server]__05vvzi-._.js")
R.c("server/chunks/lib_0f9rz97._.js")
R.c("server/chunks/_0w_4758._.js")
R.c("server/chunks/[root-of-the-server]__0bju8yw._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_chat_completions_route_actions_0mm.naf.js")
R.m(5282)
module.exports=R.m(5282).exports
