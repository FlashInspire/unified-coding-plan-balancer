var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/models/route.js")
R.c("server/chunks/_11xv.6c._.js")
R.c("server/chunks/[root-of-the-server]__0.sd7k9._.js")
R.c("server/chunks/[root-of-the-server]__0bju8yw._.js")
R.c("server/chunks/_0w_4758._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_models_route_actions_0b8t~ah.js")
R.m(55666)
module.exports=R.m(55666).exports
