var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/embeddings/route.js")
R.c("server/chunks/_11xv.6c._.js")
R.c("server/chunks/[root-of-the-server]__0kku2wi._.js")
R.c("server/chunks/_0w_4758._.js")
R.c("server/chunks/[root-of-the-server]__0bju8yw._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_embeddings_route_actions_13npmib.js")
R.m(52762)
module.exports=R.m(52762).exports
