var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon/route.js")
R.c("server/chunks/[root-of-the-server]__0uru2di._.js")
R.c("server/chunks/[root-of-the-server]__0bju8yw._.js")
R.c("server/chunks/0z~i_next_09ayzr6._.js")
R.c("server/chunks/_next-internal_server_app_icon_route_actions_01fkadx.js")
R.m(19554)
module.exports=R.m(19554).exports
